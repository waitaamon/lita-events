<?php $__env->startComponent('mail::message'); ?>
# Website Message

<?php echo e($name); ?><br>

<?php echo e($phone); ?> | <?php echo e($email); ?>


<?php echo e($message); ?>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
