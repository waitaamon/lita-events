<header class="header header-boxed-width header-background-trans header-logo-black header-topbarbox-1-left header-topbarbox-2-right header-navibox-1-left header-navibox-2-right header-navibox-3-right header-navibox-4-right">
    <div class="top-bar">
        <div class="container container-boxed-width">
            <div class="container">
                <div class="header-topbarbox-1">

                    <ul class="top-bar-contact">
                        <li class="top-bar-contact__item"><i class="icon icon-call-in"></i> +254 780 754 666  </li>
                        <li class="top-bar-contact__item"><i class="icon icon-call-in"></i>  +254 728 254 453  </li>
                        <li class="top-bar-contact__item"><i class="icon icon-envelope-open"></i> bookings@lita.co.ke</li>
                        <li class="top-bar-contact__item"><i class="icon icon-clock"></i> Mon – Fri 8.00 am – 5.00 pm </li>
                        <li class="top-bar-contact__item"><i class="icon icon-clock"></i> Sat 8.30 am – 4.00 pm </li>
                    </ul>
                </div>
                <div class="header-topbarbox-2">
                    <ul class="social-net list-inline">
                        <li class="social-net__item">
                            <a class="social-net__link text-primary_h" href="#"><i class="icon icon-social-twitter"></i></a>
                        </li>
                        <li class="social-net__item">
                            <a class="social-net__link text-primary_h" href=""><i class="icon icon-social-facebook"></i></a>
                        </li>
                        <li class="social-net__item">
                            <a class="social-net__link text-primary_h" href=""><i class="icon icon-social-linkedin"></i></a>
                        </li>
                    </ul>
                    <!-- end social-list-->
                </div>
            </div>
        </div>
    </div>
    <div class="container container-boxed-width">
        <div class="row">
            <nav id="nav" class="navbar">
                <div class="container">
                    <div class="header-navibox-1">
                        <a href="/" class="navbar-brand scroll">
                            <img src="/images/logo.png" alt="lita Events Management Companies and Agencies" class="center-logo"/>
                        </a>
                    </div>
                    <div class="header-navibox-2">

                        <ul id="menu-primary-menu" class="yamm main-menu nav navbar-nav">
                            <li><a title="HOME" href="#home">Home</a></li>
                            <li><a title="ABOUT" href="#about-us">ABOUT US</a></li>
                            <li><a title="SERVICES" href="#our-services">SERVICES</a></li>
                            <li><a title="CONTACT" href="#contact-us">CONTACT</a></li>
                        </ul>

                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>
